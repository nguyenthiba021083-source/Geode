#include <Geode/Geode.hpp>

using namespace geode::prelude;

$execute {
    log::info("Geode mod loaded!");
}
